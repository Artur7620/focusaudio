package aptyp.focusaudio.focusaudio.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.class_2561;

public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> {
            ConfigBuilder builder = ConfigBuilder.create()
                    .setParentScreen(parent)
                    .setTitle(class_2561.method_43470("FocusAudio Settings"))
                    .setSavingRunnable(FocusConfig::save);

            ConfigEntryBuilder eb = builder.entryBuilder();
            ConfigCategory general = builder.getOrCreateCategory(class_2561.method_43470("General"));

            general.addEntry(eb.startFloatField(class_2561.method_43470("Focus Boost (1.0 - 5.0)"), FocusConfig.instance.focusMultiplier)
                    .setDefaultValue(2.0f)
                    .setSaveConsumer(v -> FocusConfig.instance.focusMultiplier = v)
                    .build());

            general.addEntry(eb.startFloatField(class_2561.method_43470("Background Volume (0.0 - 1.0)"), FocusConfig.instance.backgroundVolume)
                    .setDefaultValue(0.1f)
                    .setSaveConsumer(v -> FocusConfig.instance.backgroundVolume = v)
                    .build());

            general.addEntry(eb.startIntSlider(class_2561.method_43470("Focus Angle"), FocusConfig.instance.focusAngle, 5, 90)
                    .setDefaultValue(15)
                    .setSaveConsumer(v -> FocusConfig.instance.focusAngle = v)
                    .build());

            return builder.build();
        };
    }
}
