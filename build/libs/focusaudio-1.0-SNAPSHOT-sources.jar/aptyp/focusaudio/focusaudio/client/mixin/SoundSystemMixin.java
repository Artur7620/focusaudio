package aptyp.focusaudio.focusaudio.client.mixin;

import aptyp.focusaudio.focusaudio.client.FocusConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.Map;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4235;

@Mixin(class_1140.class)
public class SoundSystemMixin {

    @Shadow
    private Map<class_1113, class_4235.class_4236> sources;

    @Inject(method = "play", at = @At("RETURN"))
    private void onPlay(class_1113 sound, CallbackInfoReturnable<class_1140.class_11518> cir) {
        applyFocus(sound);
    }

    @Inject(method = "tick(Z)V", at = @At("RETURN"))
    private void onTick(boolean paused, CallbackInfo ci) {
        if (paused || sources == null) return;
        for (var entry : sources.entrySet()) {
            var sound = entry.getKey();
            var sm = entry.getValue();
            if (sm == null || sound.method_4777() == class_1113.class_1114.field_5478) continue;
            
            float vol = Math.min(sound.method_4781() * getMultiplier(sound.method_4784(), sound.method_4779(), sound.method_4778()), 2.5f);
            sm.method_19735(src -> src.method_19647(vol));
        }
    }

    private void applyFocus(class_1113 sound) {
        if (sound == null || sources == null || sound.method_4777() == class_1113.class_1114.field_5478) return;
        var sm = sources.get(sound);
        if (sm == null) return;
        
        float vol = Math.min(sound.method_4781() * getMultiplier(sound.method_4784(), sound.method_4779(), sound.method_4778()), 2.5f);
        sm.method_19735(src -> src.method_19647(vol));
    }

    private float getMultiplier(double x, double y, double z) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return 1.0f;

        class_1657 player = mc.field_1724;
        class_243 eye = player.method_33571();
        class_243 toSound = new class_243(x - eye.field_1352, y - eye.field_1351, z - eye.field_1350);
        double dist = toSound.method_1033();
        
        double dot = player.method_5828(1.0f).method_1026(toSound.method_1029());
        double configAngleCos = Math.cos(Math.toRadians(FocusConfig.instance.focusAngle));
        boolean isFocused = dot >= configAngleCos;

        if (dist < 1.5) return 1.2f; 

        if (isFocused) {
            return (dist > 25.0) ? 0.8f : FocusConfig.instance.focusMultiplier; 
        } else {
            return (dist > 5.0) ? FocusConfig.instance.backgroundVolume : 0.4f;
        }
    }
}
